from .naturalneighbor import griddata

__all__ = [
    'griddata',
]
